import AuthenticationRepositories from '../repositories/authentication-repositories.js';
import UserRepositories from '../../users/repositories/user-repositories.js';
import TokenManager from '../../../security/token-manager.js';
import response from '../../../utils/response.js';
import { InvariantError, AuthenticationError, AuthorizationError } from '../../../exceptions/index.js';

class AuthenticationController{
    async login(req, res, next) {
        const { email, password } = req.validated;
        const userId = await UserRepositories.verifyUserCredential(email, password);

        if(!userId) {
            return next(new AuthenticationError('Kredensial yang Anda berikan salah'));
        }

        const verifiedUser = await UserRepositories.verifyVerfiedUser(userId);

        if(!verifiedUser) {
            return next(new AuthorizationError('Akun belum terverifikasi')); // 403 forbidden
        }

        const accessToken = TokenManager.generateAccessToken({ id: userId });
        const refreshToken = TokenManager.generateRefreshToken({ id: userId });

        await AuthenticationRepositories.addRefreshToken(refreshToken);

        return response(res, 201, 'Authentication berhasil ditambahkan', {
            accessToken,
            refreshToken,
        });
    }

    async refreshToken(req, res, next) {
        const { refreshToken } = req.validated;

        const result = await AuthenticationRepositories.verifyRefreshToken(refreshToken);

        if(!result){
            return next(new InvariantError('Refresh token tidak valid'));
        }

        const { id } = TokenManager.verifyRefreshToken(refreshToken);
        const accessToken = TokenManager.generateAccessToken({ id });

        return response(res, 200, 'Access Token berhasil diperbarui', { accessToken });
    }

    async logout(req, res, next) {
        const { refreshToken } = req.validated;

        const result = await AuthenticationRepositories.verifyRefreshToken(refreshToken);

        if(!result){
            return next(new InvariantError('Refresh token tidak valid'));
        }

        await AuthenticationRepositories.deleteRefreshToken(refreshToken)

        return response(res, 200, 'Refresh token berhasil dihapus');
    }
}

export default new AuthenticationController;