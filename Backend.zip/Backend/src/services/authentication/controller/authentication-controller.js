import AuthenticationRepositories from '../repositories/authentication-repositories.js';
import UserRepositories from '../../users/repositories/user-repositories.js';
import TokenManager from '../../../security/token-manager.js';
import response from '../../../utils/response.js';
import { InvariantError, AuthenticationError } from '../../../exceptions/index.js';

export const login = async (res, req, next) => {
    const { email, password } = req.validated;
    const userId = await UserRepositories.verifyUserCredential(email, password);

    if(!userId) {
        return next(new AuthenticationError('Kredensial yang Anda berikan salah'));
    }

    const accessToken = TokenManager.generateAccessToken({ id: userId });
    const refreshToken = TokenManager.generateRefreshToken({ id: userId });

    await AuthenticationRepositories.addRefreshToken(refreshToken);

    return response(res, 201, 'Authentication berhasil ditambahkan', {
        accessToken,
        refreshToken,
    });
}

export const refreshToken = async (req, res, next) => {
    const { refreshToken } = req.validated;

    const result = await AuthenticationRepositories.verifyRefreshToken(refreshToken); // cek ada di db or not

    if(!result){
        return next(new InvariantError('Refresh token tidak valid'));
    }

    const { id } = TokenManager.verifyRefreshToken(refreshToken); // cek ke asliannya
    const accessToken = TokenManager.generateAccessToken({ id });

    return response(res, 200, 'Access Token berhasil diperbarui', { accessToken });
}

export const logout = async (req, res, next) => {
    const { refreshToken } = req.validated;

    const result = await AuthenticationRepositories.verifyRefreshToken(refreshToken);

    if(!result){
        return next(new InvariantError('Refresh token tidak valid'));
    }

    await AuthenticationRepositories.deleteRefreshToken(refreshToken)

    return response(res, 200, 'Refresh token berhasil dihapus');
}