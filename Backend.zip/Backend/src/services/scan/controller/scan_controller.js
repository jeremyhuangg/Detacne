import scanRepositories from '../repositories/scan_repositories.js';
import response from '../../../utils/response.js';

class ScanController{
    async scan (req, res, next) {
        const { image_key } = req.validated;

        response(res, 200, 'scan berhasil');
    }

    async save (req, res, next) {
        
    }
};

export default new ScanController;