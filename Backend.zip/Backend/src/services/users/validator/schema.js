import Joi from 'joi';

export const userPayloadSchema = Joi.object({
    nickname: Joi.string().min(2).max(250).required(),
    email: Joi.string().email().required(),
    password: Joi.string().min(8).alphanum().required(),
    gender: Joi.string().required(),
    dateOfBirth: Joi.string().required(),
});