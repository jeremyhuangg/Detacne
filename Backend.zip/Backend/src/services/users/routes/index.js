import { Router } from 'express';
import userController from '../controller/user-controller.js';
import forgotPasswordController from '../controller/forgot-password-controller.js';
import { validate } from '../../../middlewares/validate.js';
import { userPayloadSchema, changePasswordPayloadSchema, forgotPasswordPayloadSchema, resetPasswordPayloadSchema } from '../validator/schema.js';

const router = Router();

router.post('/users', validate(userPayloadSchema), userController.createUser);
router.get('/users/:id', userController.getUserById);
router.put('/users/change-password', validate(changePasswordPayloadSchema), userController.changePassword);
router.post('/forgot-password', validate(forgotPasswordPayloadSchema), forgotPasswordController.forgotPassword);
router.post('/reset-password', validate(resetPasswordPayloadSchema), forgotPasswordController.resetPassword);

export default router;